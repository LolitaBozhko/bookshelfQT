#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //Начальное состояние
    BookID=0;
    bShelfID=0;
    shelfID=0;
    ui->groupBox_book->setEnabled(false);
    ui->groupBox_shelf->setEnabled(false);
    ui->pushButton_delbshelf->setEnabled(false);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_addbshelf_clicked()
{
    //Создать шкаф
       Book_shelf bs;
       //Добавить шкаф в список
       bookShelfs.push_back(bs);
       ui->listWidget_bshelfs->addItem(QString::number(bookShelfs.size()));
}

void MainWindow::on_listWidget_bshelfs_itemClicked(QListWidgetItem *item)
{
    //Получить ID шкафа
    bShelfID = item->text().toInt();

    //активировать эл-ты интерфейса
    ui->pushButton_delbshelf->setEnabled(true);
    ui->groupBox_shelf->setEnabled(true);
    ui->pushButton_delshelf->setEnabled(false);

    //Очистить список
    ui->listWidget_shelfs->clear();
    ui->listWidget_books->clear();

    //получить кол-во полок
    int shelfN = bookShelfs[bShelfID-1].getShelfNumber();

    //Наполнить список полок
    if(shelfN>0){
        for (int i=1;i<=shelfN;i++){
            ui->listWidget_shelfs->addItem(QString::number(i));
        }
    }
}




void MainWindow::on_pushButton_addshelf_clicked()
{
    bookShelfs [shelfID-1].addshelf();
    int shelfN = bookShelfs[shelfID-1].getShelfNumber();
    ui->listWidget_shelfs->addItem(QString::number(shelfN));
}
