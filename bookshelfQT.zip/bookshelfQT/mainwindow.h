#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "PrintBook.h"
#include "shelf.h"
#include "Book_shelf.h"
#include <QListWidgetItem>
#include <vector>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_addbshelf_clicked();

    void on_listWidget_bshelfs_itemClicked(QListWidgetItem *item);

    void on_pushButton_addshelf_clicked();

private:
    Ui::MainWindow *ui;
    vector<Book_shelf> bookShelfs; //Шкафы
   int bShelfID;
   int shelfID;
   int BookID;
};
#endif // MAINWINDOW_H
