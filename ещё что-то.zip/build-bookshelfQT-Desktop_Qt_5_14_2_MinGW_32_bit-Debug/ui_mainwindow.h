/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout;
    QGroupBox *groupBox_bshelf;
    QVBoxLayout *verticalLayout_4;
    QListWidget *listWidget_bshelfs;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *pushButton_addbshelf;
    QPushButton *pushButton_delbshelf;
    QVBoxLayout *verticalLayout_2;
    QGroupBox *groupBox_shelf;
    QVBoxLayout *verticalLayout_5;
    QListWidget *listWidget_shelfs;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *pushButton_addshelf;
    QPushButton *pushButton_delshelf;
    QVBoxLayout *verticalLayout_3;
    QGroupBox *groupBox_book;
    QVBoxLayout *verticalLayout_6;
    QListWidget *listWidget_books;
    QLabel *label;
    QLineEdit *lineEdit;
    QLabel *label_2;
    QLineEdit *lineEdit_2;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_3;
    QSpinBox *spinBox;
    QHBoxLayout *horizontalLayout_5;
    QPushButton *pushButton_addbook;
    QPushButton *pushButton_delbook;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1143, 597);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        horizontalLayout = new QHBoxLayout(centralwidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        groupBox_bshelf = new QGroupBox(centralwidget);
        groupBox_bshelf->setObjectName(QString::fromUtf8("groupBox_bshelf"));
        verticalLayout_4 = new QVBoxLayout(groupBox_bshelf);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        listWidget_bshelfs = new QListWidget(groupBox_bshelf);
        listWidget_bshelfs->setObjectName(QString::fromUtf8("listWidget_bshelfs"));

        verticalLayout_4->addWidget(listWidget_bshelfs);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        pushButton_addbshelf = new QPushButton(groupBox_bshelf);
        pushButton_addbshelf->setObjectName(QString::fromUtf8("pushButton_addbshelf"));

        horizontalLayout_2->addWidget(pushButton_addbshelf);

        pushButton_delbshelf = new QPushButton(groupBox_bshelf);
        pushButton_delbshelf->setObjectName(QString::fromUtf8("pushButton_delbshelf"));

        horizontalLayout_2->addWidget(pushButton_delbshelf);


        verticalLayout_4->addLayout(horizontalLayout_2);


        verticalLayout->addWidget(groupBox_bshelf);


        horizontalLayout->addLayout(verticalLayout);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        groupBox_shelf = new QGroupBox(centralwidget);
        groupBox_shelf->setObjectName(QString::fromUtf8("groupBox_shelf"));
        verticalLayout_5 = new QVBoxLayout(groupBox_shelf);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        listWidget_shelfs = new QListWidget(groupBox_shelf);
        listWidget_shelfs->setObjectName(QString::fromUtf8("listWidget_shelfs"));

        verticalLayout_5->addWidget(listWidget_shelfs);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        pushButton_addshelf = new QPushButton(groupBox_shelf);
        pushButton_addshelf->setObjectName(QString::fromUtf8("pushButton_addshelf"));

        horizontalLayout_4->addWidget(pushButton_addshelf);

        pushButton_delshelf = new QPushButton(groupBox_shelf);
        pushButton_delshelf->setObjectName(QString::fromUtf8("pushButton_delshelf"));

        horizontalLayout_4->addWidget(pushButton_delshelf);


        verticalLayout_5->addLayout(horizontalLayout_4);


        verticalLayout_2->addWidget(groupBox_shelf);


        horizontalLayout->addLayout(verticalLayout_2);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        groupBox_book = new QGroupBox(centralwidget);
        groupBox_book->setObjectName(QString::fromUtf8("groupBox_book"));
        verticalLayout_6 = new QVBoxLayout(groupBox_book);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        listWidget_books = new QListWidget(groupBox_book);
        listWidget_books->setObjectName(QString::fromUtf8("listWidget_books"));

        verticalLayout_6->addWidget(listWidget_books);

        label = new QLabel(groupBox_book);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout_6->addWidget(label);

        lineEdit = new QLineEdit(groupBox_book);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));

        verticalLayout_6->addWidget(lineEdit);

        label_2 = new QLabel(groupBox_book);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout_6->addWidget(label_2);

        lineEdit_2 = new QLineEdit(groupBox_book);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));

        verticalLayout_6->addWidget(lineEdit_2);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        label_3 = new QLabel(groupBox_book);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_6->addWidget(label_3);

        spinBox = new QSpinBox(groupBox_book);
        spinBox->setObjectName(QString::fromUtf8("spinBox"));

        horizontalLayout_6->addWidget(spinBox);


        verticalLayout_6->addLayout(horizontalLayout_6);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        pushButton_addbook = new QPushButton(groupBox_book);
        pushButton_addbook->setObjectName(QString::fromUtf8("pushButton_addbook"));

        horizontalLayout_5->addWidget(pushButton_addbook);

        pushButton_delbook = new QPushButton(groupBox_book);
        pushButton_delbook->setObjectName(QString::fromUtf8("pushButton_delbook"));

        horizontalLayout_5->addWidget(pushButton_delbook);


        verticalLayout_6->addLayout(horizontalLayout_5);


        verticalLayout_3->addWidget(groupBox_book);


        horizontalLayout->addLayout(verticalLayout_3);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1143, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        groupBox_bshelf->setTitle(QCoreApplication::translate("MainWindow", "\320\250\320\272\320\260\321\204\321\213", nullptr));
        pushButton_addbshelf->setText(QCoreApplication::translate("MainWindow", "\320\224\320\276\320\261\320\260\320\262\320\270\321\202\321\214", nullptr));
        pushButton_delbshelf->setText(QCoreApplication::translate("MainWindow", "\320\243\320\264\320\260\320\273\320\270\321\202\321\214", nullptr));
        groupBox_shelf->setTitle(QCoreApplication::translate("MainWindow", "\320\237\320\276\320\273\320\272\320\270", nullptr));
        pushButton_addshelf->setText(QCoreApplication::translate("MainWindow", "\320\224\320\276\320\261\320\260\320\262\320\270\321\202\321\214", nullptr));
        pushButton_delshelf->setText(QCoreApplication::translate("MainWindow", "\320\243\320\264\320\260\320\273\320\270\321\202\321\214", nullptr));
        groupBox_book->setTitle(QCoreApplication::translate("MainWindow", "\320\232\320\275\320\270\320\263\320\270", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "\320\220\320\262\321\202\320\276\321\200", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "\320\235\320\260\320\267\320\262\320\260\320\275\320\270\320\265", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "\320\241\321\202\321\200\320\260\320\275\320\270\321\206\321\213", nullptr));
        pushButton_addbook->setText(QCoreApplication::translate("MainWindow", "\320\224\320\276\320\261\320\260\320\262\320\270\321\202\321\214", nullptr));
        pushButton_delbook->setText(QCoreApplication::translate("MainWindow", "\320\243\320\264\320\260\320\273\320\270\321\202\321\214", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
